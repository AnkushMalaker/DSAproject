package com.example.parsaniahardik.google_map_path_two_location;

public interface TaskLoadedCallback {
    void onTaskDone(Object... values);
}
